package radiant.seven;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class PathControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void testGetMapData() throws Exception {
        mockMvc.perform(get("/api/map"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.roadNetwork").exists());
    }

    @Test
    void testFindPath() throws Exception {
        String requestBody = """
                {
                    "startX": 1,
                    "startY": 1,
                    "endX": 5,
                    "endY": 5
                }
                """;

        mockMvc.perform(post("/api/findPath")
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBody))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray());
    }

    @Test
    void testFindPathWithDifferentCoordinates() throws Exception {
        String requestBody = """
                {
                    "startX": 10,
                    "startY": 10,
                    "endX": 20,
                    "endY": 20
                }
                """;

        mockMvc.perform(post("/api/findPath")
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBody))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray());
    }
}