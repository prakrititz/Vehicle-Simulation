package radiant.seven;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class EVControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        // Clear the EV map before each test
        if (EVController.evMap != null) {
            EVController.evMap.clear();
        }
    }

    @Test
    void testGetAllEVs() throws Exception {
        mockMvc.perform(get("/api/ev/all"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON));
    }

    @Test
    void testGetEVStatusNotFound() throws Exception {
        mockMvc.perform(get("/api/ev/NonExistentEV/status"))
                .andExpect(status().isNotFound());
    }

    @Test
    void testDeleteNonExistentEV() throws Exception {
        mockMvc.perform(delete("/api/ev/NonExistentEV"))
                .andExpect(status().isNotFound());
    }

    @Test
    void testGetTrafficSignals() throws Exception {
        mockMvc.perform(get("/api/ev/traffic/signals"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON));
    }

    @Test
    void testChangeTrafficSignals() throws Exception {
        mockMvc.perform(post("/api/ev/traffic/change"))
                .andExpect(status().isOk());
    }

    @Test
    void testCreateNewEV() throws Exception {
        String requestBody = """
                {
                    "name": "TestEV1",
                    "startX": 5,
                    "startY": 5,
                    "endX": 10,
                    "endY": 10,
                    "type": 1,
                    "charge": 100,
                    "chargingRate": 5,
                    "vehicleType": "sedan"
                }
                """;

        mockMvc.perform(post("/api/ev/new")
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBody))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("TestEV1"));
    }

    @Test
    void testGetEVStatusAfterCreation() throws Exception {
        // First create an EV
        String requestBody = """
                {
                    "name": "TestEV2",
                    "startX": 3,
                    "startY": 3,
                    "endX": 8,
                    "endY": 8,
                    "type": 1,
                    "charge": 80,
                    "chargingRate": 5,
                    "vehicleType": "coupe"
                }
                """;

        mockMvc.perform(post("/api/ev/new")
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBody))
                .andExpect(status().isOk());

        // Then get its status
        mockMvc.perform(get("/api/ev/TestEV2/status"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.charge").value(80));
    }

    @Test
    void testDeleteEV() throws Exception {
        // First create an EV
        String requestBody = """
                {
                    "name": "TestEV3",
                    "startX": 2,
                    "startY": 2,
                    "endX": 7,
                    "endY": 7,
                    "type": 1,
                    "charge": 90,
                    "chargingRate": 5,
                    "vehicleType": "hatchback"
                }
                """;

        mockMvc.perform(post("/api/ev/new")
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBody))
                .andExpect(status().isOk());

        // Then delete it
        mockMvc.perform(delete("/api/ev/TestEV3"))
                .andExpect(status().isOk());

        // Verify it's deleted
        mockMvc.perform(get("/api/ev/TestEV3/status"))
                .andExpect(status().isNotFound());
    }
}