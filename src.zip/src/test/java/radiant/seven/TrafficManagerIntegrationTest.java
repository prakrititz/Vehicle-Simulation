package radiant.seven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class TrafficManagerIntegrationTest {

    @Test
    void testTrafficManagerInitialization() {
        TrafficManager manager = TrafficManager.getInstance();
        assertThat(manager).isNotNull();
    }

    @Test
    void testTrafficManagerSingletonPattern() {
        TrafficManager instance1 = TrafficManager.getInstance();
        TrafficManager instance2 = TrafficManager.getInstance();
        assertThat(instance1).isSameAs(instance2);
    }

    @Test
    void testTrafficLightsListExists() {
        assertThat(TrafficManager.trafficLights).isNotNull();
    }

    @Test
    void testChangeSignalsMethod() {
        // Just verify the method can be called without errors
        TrafficManager.changeSignals();
        assertThat(TrafficManager.trafficLights).isNotNull();
    }
}